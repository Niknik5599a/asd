.. note::

  The code examples are often written in an interactive session syntax, which is indicated by
  lines beginning with ``>>>`` or ``...``. This enables us to run automatic tests against the examples
  to ensure they keep working while the library is evolving. When we want to copy and paste example
  code to play with it, we need to remove these extra characters to get runnable valid Python code.

Receipts
========

Receipt
-------

.. autoclass:: eth.rlp.receipts.Receipt
  :members:

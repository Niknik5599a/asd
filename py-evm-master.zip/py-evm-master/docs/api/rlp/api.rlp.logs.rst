Logs
====

Log
---

.. autoclass:: eth.rlp.logs.Log
  :members:

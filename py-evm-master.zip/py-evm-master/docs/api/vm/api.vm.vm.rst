VM
==

VM
--

    .. # We need to exclude the `get_prev_hashes` method as the functool decorator breaks autodoc

.. autoclass:: eth.vm.base.VM
  :members:
  :exclude-members: get_prev_hashes


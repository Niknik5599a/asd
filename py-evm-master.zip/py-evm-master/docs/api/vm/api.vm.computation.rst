Computation
===========

BaseComputation
---------------

.. autoclass:: eth.vm.computation.BaseComputation
  :members:

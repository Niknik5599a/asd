Opcode
=======

.. autoclass:: eth.vm.opcode.Opcode
  :members:


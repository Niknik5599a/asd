BaseTransactionContext
======================

.. autoclass:: eth.vm.transaction_context.BaseTransactionContext
  :members:


State
=====

BaseState
---------

.. autoclass:: eth.vm.state.BaseState
  :members:


BaseTransactionExecutor
-----------------------

.. autoclass:: eth.vm.state.BaseTransactionExecutor
  :members:

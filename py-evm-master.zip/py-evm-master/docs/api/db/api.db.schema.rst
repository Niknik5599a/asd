Schema
======

SchemaV1
--------

.. autoclass:: eth.db.schema.SchemaV1
  :members:
Backends
========

BaseDB
------

.. autoclass:: eth.db.backends.base.BaseDB
  :members:

LevelDB
-------

.. autoclass:: eth.db.backends.level.LevelDB
  :members:

MemoryDB
--------

.. autoclass:: eth.db.backends.memory.MemoryDB
  :members:
Batch
=====

BatchDB
~~~~~~~

.. autoclass:: eth.db.batch.BatchDB
  :members:

Journal
=======

JournalDB
---------

.. autoclass:: eth.db.journal.JournalDB
  :members:
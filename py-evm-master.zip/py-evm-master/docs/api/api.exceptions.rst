Exceptions
==========


.. automodule:: eth.exceptions
  :members:

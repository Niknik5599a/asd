def test_import():
    import eth  # noqa: F401

from eth.vm.transaction_context import (
    BaseTransactionContext,
)


class FrontierTransactionContext(BaseTransactionContext):
    pass

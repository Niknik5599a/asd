from eth_utils import (
    denoms,
)

GAS_EXTCODEHASH_EIP1052 = 400

EIP1234_BLOCK_REWARD = 2 * denoms.ether

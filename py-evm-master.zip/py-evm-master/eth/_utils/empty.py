class Empty:
    pass


empty = Empty()
